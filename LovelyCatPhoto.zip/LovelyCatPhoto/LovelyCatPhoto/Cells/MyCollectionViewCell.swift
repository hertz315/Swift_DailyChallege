//
//  MyCollectionViewCell.swift
//  LovelyCatPhoto
//
//  Created by Hertz on 9/2/22.
//

import UIKit

class MyCollectionViewCell: UICollectionViewCell {
    
    static let cellId = "MyCollectionViewCell"
    static let className = "MyCollectionViewCell"
    

    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
 
}
